
import { SlashCommandBuilder } from 'discord.js';
export const data = new SlashCommandBuilder().setName('help').setDescription('Shows help info');
export async function execute(interaction) { await interaction.reply('Available commands: /ping, /play, /ask, /balance, /rank, /meme'); }
